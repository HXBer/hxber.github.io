#include <stdio.h>
#include <unistd.h>

char shellcode[1024];

int main()
{
    setbuf(stdin, 0);
    setbuf(stdout, 0);
    setbuf(stderr, 0);
    read(0, shellcode, 1023);
    if (strstr(shellcode, "sh"))
    {
        puts("shellcode detected!");
        return -1;
    }
    (*(void (*)()) shellcode)();
}
